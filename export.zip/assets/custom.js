$(' .product-grid').slick({
      dots: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      speed: 500,
      arrows : false,
   infinite:false,
      responsive: [
    {
      breakpoint: 749,
      settings: {
            slidesToShow: 1,
      }
    },
  ]
});


$('.slider-grid-wrapper').slick({
dots: false,
infinite: false, 
slidesToShow: 1,
slidesToScroll: 1,
speed: 500,
arrows : false,
adaptiveHeight: true

});

if(window.location.pathname.includes('products')){
$('.main_images').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  fade: true,
  infinite: false, 
  asNavFor: '.thumb_images'
});
$('.thumb_images').slick({
  slidesToShow: 5,
  slidesToScroll: 1,
  asNavFor: '.main_images',
  dots: false,
  centerMode: false,
  focusOnSelect: true,
  infinite: false
});
}
else{
 $('.main_images').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: true,
  asNavFor: '.thumb_images'
});
$('.thumb_images').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  asNavFor: '.main_images',
  dots: false,
  centerMode: false,
  focusOnSelect: true
});
}

$('.custom_variant_picker input').on('click', function() {
let thus=$(this);
let val = thus.parent().find('input:checked').attr("data-val");
let varid = thus.parent().find('input:checked').attr("data-varid");
thus.parents('.quick-view_product_wrapper').find(`.colordivs[data-varname=${val}]`).addClass('active_color').siblings().removeClass('active_color');
thus.parents('.quick-view_product_wrapper').find('input[name="id"]').val(varid);
});


$('.landing-btn, .landing-button2, .comfie-btn, .kids-btn').click(function(e) {
e.preventDefault();
$('.quick-view-section_inner').addClass('openpopup');
$('button.quick-view_popup_close,.quick-view_popup_overlay').click(function(e) {
e.preventDefault();
$('.quick-view-section_inner').removeClass('openpopup');
});

});
$('.product-form__input.color input').on('click', function() {
let thus=$(this);
   
let val = thus.parent().find('input:checked').attr("data-val");
thus.parents('.product__info-wrapper').siblings().find(`.colordivs[data-varname=${val}]`).addClass('active_color').siblings().removeClass('active_color');
  
});


 $('.template-collection .product-grid').slick('unslick');
$(".color_btn_wrapper").each(function(){
 $(this).parents(".product-form__input").find('.option_val').text($(this).find("input:checked").val())
})

$('.color_btn_wrapper input').on('click', function() {


 var name = $(this).attr('value');
  console.log(name);
 $(this).parents(".product-form__input").find('.option_val').text(name);
});




    $('.product-specidications .specifications-content-wrapper').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll:1,
      arrows:false,
      dots:true,
      adaptiveHeight: true,
      autoplay: true,
      autoplaySpeed: 3000,
         responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
      }
    },
            {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
      }
    }
  ]
    });



    $('.product-additional-features .specifications-content-wrapper').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll:1,
      arrows:false,
      dots:true,
      adaptiveHeight: true,
      autoplay: true,
      autoplaySpeed: 3000,
      responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
      }
    },
            {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
      }
    }
  ]
    });









